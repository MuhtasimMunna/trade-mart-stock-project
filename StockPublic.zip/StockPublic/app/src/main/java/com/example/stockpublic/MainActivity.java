package com.example.stockpublic;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ListView;

import com.google.gson.Gson;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private ArrayList<Company> companyList=new ArrayList<Company>();
    public static ListView lv;
    private ListAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        lv=findViewById(R.id.companyList);
        GatherCompanyInfo CompanyList=new GatherCompanyInfo(companyList,this,adapter);
        CompanyList.execute();
        MainActivity.lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            public void onItemClick(AdapterView<?> parentAdapter, View view, int position,
                                    long id) {


                // We know the View is a <extView so we can cast it
               if(adapter==null){
                   adapter=new ListAdapter(getContext(),R.layout.adapter_view,companyList);
               }


            }
        });
    }
    private Context getContext(){
        return this;
    }
}
